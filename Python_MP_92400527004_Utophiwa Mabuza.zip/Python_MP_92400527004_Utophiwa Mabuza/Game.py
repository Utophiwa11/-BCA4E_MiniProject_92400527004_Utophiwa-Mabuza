import tkinter as tk
from tkinter import messagebox
import random
import sqlite3

# --- Database Functions ---
def init_db():
    conn = sqlite3.connect('game_data.db')
    cursor = conn.cursor()
    cursor.execute('CREATE TABLE IF NOT EXISTS stats (id INTEGER PRIMARY KEY, wins INTEGER, losses INTEGER, ties INTEGER)')
    cursor.execute('SELECT COUNT(*) FROM stats')
    if cursor.fetchone()[0] == 0:
        cursor.execute('INSERT INTO stats (wins, losses, ties) VALUES (0, 0, 0)')
    conn.commit()
    conn.close()

def update_db(result):
    conn = sqlite3.connect('game_data.db')
    cursor = conn.cursor()
    if result == "win": cursor.execute('UPDATE stats SET wins = wins + 1 WHERE id = 1')
    elif result == "loss": cursor.execute('UPDATE stats SET losses = losses + 1 WHERE id = 1')
    else: cursor.execute('UPDATE stats SET ties = ties + 1 WHERE id = 1')
    conn.commit()
    conn.close()

def reset_db():
    if messagebox.askyesno("Reset", "Are you sure you want to delete all scores?"):
        conn = sqlite3.connect('game_data.db')
        cursor = conn.cursor()
        cursor.execute('UPDATE stats SET wins=0, losses=0, ties=0 WHERE id = 1')
        conn.commit()
        conn.close()
        refresh_stats()
        lbl_result.config(text="Scores Reset!", fg="orange")

def get_stats():
    conn = sqlite3.connect('game_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT wins, losses, ties FROM stats WHERE id = 1')
    res = cursor.fetchone()
    conn.close()
    return res

# --- Game Logic ---
is_paused = False

def toggle_pause():
    global is_paused
    is_paused = not is_paused
    btn_pause.config(text="RESUME" if is_paused else "PAUSE")
    lbl_result.config(text="GAME PAUSED" if is_paused else "Ready to play?", fg="red" if is_paused else "blue")

def play(user_choice):
    if is_paused:
        return

    options = ['Rock', 'Paper', 'Scissors']
    difficulty = diff_var.get()

    # Difficulty Logic
    if difficulty == "Hard" and random.random() < 0.15:
        # Computer cheats: picks the move that beats you
        cheats = {"Rock": "Paper", "Paper": "Scissors", "Scissors": "Rock"}
        computer_choice = cheats[user_choice]
    else:
        computer_choice = random.choice(options)
    
    if user_choice == computer_choice:
        res, msg = "tie", f"Tie! Both chose {user_choice}"
    elif (user_choice == 'Rock' and computer_choice == 'Scissors') or \
         (user_choice == 'Paper' and computer_choice == 'Rock') or \
         (user_choice == 'Scissors' and computer_choice == 'Paper'):
        res, msg = "win", f"You Win! {user_choice} beats {computer_choice}"
    else:
        res, msg = "loss", f"You Lose! {computer_choice} beats {user_choice}"
    
    update_db(res)
    lbl_result.config(text=msg, fg="green" if res=="win" else "red" if res=="loss" else "gray")
    refresh_stats()

def refresh_stats():
    w, l, t = get_stats()
    lbl_stats.config(text=f"Wins: {w} | Losses: {l} | Ties: {t}")

# --- GUI Setup ---
init_db()
root = tk.Tk()
root.title("RPS Extreme")
root.geometry("450x450")

# Header & Difficulty
tk.Label(root, text="Rock Paper Scissors", font=("Arial", 18, "bold")).pack(pady=10)
diff_var = tk.StringVar(value="Normal")
tk.Label(root, text="Difficulty:").pack()
tk.OptionMenu(root, diff_var, "Normal", "Hard").pack()

# Game Buttons
btn_frame = tk.Frame(root)
btn_frame.pack(pady=20)
tk.Button(btn_frame, text="Rock", width=10, command=lambda: play("Rock")).grid(row=0, column=0, padx=5)
tk.Button(btn_frame, text="Paper", width=10, command=lambda: play("Paper")).grid(row=0, column=1, padx=5)
tk.Button(btn_frame, text="Scissors", width=10, command=lambda: play("Scissors")).grid(row=0, column=2, padx=5)

lbl_result = tk.Label(root, text="Ready?", font=("Arial", 12, "italic"))
lbl_result.pack(pady=10)

# Control Buttons
ctrl_frame = tk.Frame(root)
ctrl_frame.pack(pady=10)
btn_pause = tk.Button(ctrl_frame, text="PAUSE", width=10, bg="yellow", command=toggle_pause)
btn_pause.pack(side="left", padx=5)
tk.Button(ctrl_frame, text="RESET SCORE", width=12, bg="lightcoral", command=reset_db).pack(side="left", padx=5)

lbl_stats = tk.Label(root, text="", font=("Arial", 10, "bold"), bg="#f0f0f0", width=40)
lbl_stats.pack(side="bottom", pady=20)

refresh_stats()
root.mainloop()
