========================================================================
PROJECT TITLE: Rock-Paper-Scissors with Persistent SQLite Integration
ACADEMIC YEAR: 2025 – 26
COURSE: BACHELOR OF COMPUTER APPLICATIONS (B.C.A.) - SEMESTER 4
========================================================================

1. INTRODUCTION
---------------
This is a Graphical User Interface (GUI) based application of the classic 
Rock-Paper-Scissors game. The project demonstrates the integration of 
Python's Tkinter library for the frontend and SQLite3 for backend 
database management.

2. FEATURES
-----------
* User vs Computer gameplay.
* Persistent Score Tracking: Wins, Losses, and Ties are saved in a 
  local database (game_data.db).
* Real-time UI updates.
* Automated database initialization.

3. PREREQUISITES
----------------
To run this project, you must have the following installed:
* Python 3.x (Tested on version 3.13.6)
* Tkinter (Usually bundled with Python; use `sudo apt-get install 
  python3-tk` on Linux if missing)
* SQLite3 (Built-in with Python)

4. FILE STRUCTURE
-----------------
* python_project.py  : The main application source code.
* game_data.db       : The database file (generated automatically 
                       on first run).
* README.txt         : This instruction file.

5. HOW TO RUN
-------------
1. Open your terminal or Command Prompt.
2. Navigate to the directory containing 'python_project.py'.
3. Run the following command:
   python python_project.py
4. Use the on-screen buttons to play.

6. DATABASE DETAILS
-------------------
The application uses a table named 'stats' to store data.
Columns:
- id: Primary Key
- wins: Integer count of player victories
- losses: Integer count of computer victories
- ties: Integer count of draws

7. TROUBLESHOOTING
------------------
* Database Error: If the game fails to load stats, ensure you have 
  write permissions in the folder to allow the creation of 
  'game_data.db'.
* Resolution: If the window is too small, the geometry is set 
  to 400x350, which can be adjusted in the source code.

8. AUTHOR
---------
Student Name: [Your Name]
Enrollment No: [Your Enrollment No]
University: Marwadi University [cite: 8]
========================================================================